package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.BankBean;

public interface IBank {

	String validate(double amount);

	int addinfo(BankBean bean) throws SQLException;

	BankBean retrievebyid(int id);
	

}
