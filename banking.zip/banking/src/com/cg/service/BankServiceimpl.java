package com.cg.service;

import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.dao.DaoImpl;
import com.cg.dao.IDao;

public class BankServiceimpl implements IBank {

	String commision=null;
	static IDao dao=null;

	@Override
	public String validate(double amount) {
		if(amount<5000)
		{
	 commision="50";	
		}else if(amount>5000&&amount<1000)
		{
		commision="100";
		}else if(amount>1000)
		{
			commision="500";
		}
		return commision;
	}

	@Override
	public int addinfo(BankBean bean) throws SQLException {
		dao=new DaoImpl();
		return dao.addinfo(bean);
	}

	@Override
	public BankBean retrievebyid(int id) {
		dao=new DaoImpl();
		return dao.retrievebyid(id);
	}



	
		

}
