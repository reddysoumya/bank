package com.cg.ui;

import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.BankBean;
import com.cg.service.BankServiceimpl;
import com.cg.service.IBank;

public class Client {
	static Scanner sc=null;
	static IBank ser=null;
	
	public static void main(String[] args) throws SQLException {
		 sc=new Scanner(System.in);
		System.out.println("***BANKING APPLICATION***");
		System.out.println("1.enter details");
		System.out.println("2.fetch details");
		System.out.println("3.exit");
		System.out.println("enter your choice");
		int choice=sc.nextInt();
		double amount;
		switch (choice) {
		case 1:
			System.out.println("enter your name");
			String name=sc.next();
			System.out.println("enter your mobile no");
			String mob=sc.next();
			System.out.println("enter your state");
			String state=sc.next();
			System.out.println("enter your branch");
			String branch=sc.next();
			System.out.println("enter your accno");
			String accno=sc.next();
			System.out.println("enter your amount");
			amount=sc.nextDouble();
			ser=new BankServiceimpl();
			String commision=ser.validate(amount);
			
			BankBean bean=new BankBean(name, mob, state, branch, accno, amount, commision);
			//double total=amount+bean.getCommission();
			int res=0;
			try {
			res=addinfo(bean);	
			if(res>0) {
				System.out.println("data inserted,Id is: "+res);
	
			}
			else {
				System.out.println("try again");
			}
			}
			catch(SQLException e)
			{
				System.out.println(e.getMessage());
			}
			
			break;
		case 2:
			System.out.println("enter id to display data");
			int id=sc.nextInt();
			BankBean b=null;
			b=retrievebyid(id);
			System.out.println(b);			
break;
		default:
			break;
		}
		
	}

	private static BankBean retrievebyid(int id) {
		ser=new BankServiceimpl();
		return ser.retrievebyid(id);
	}

	private static int addinfo(BankBean bean) throws SQLException {
		ser=new BankServiceimpl();
		int res=ser.addinfo(bean);
		return res;
	}
}
