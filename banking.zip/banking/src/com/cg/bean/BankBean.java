package com.cg.bean;

public class BankBean {
		 private String name;
		private String mob;
		private String state;
		private String branch;
		private String accno;
		private String tdate;
		private double amount;
		private String commission;
	    private int id;
	    
		@Override
		public String toString() {
			return "BankBean [name=" + name + ", mob=" + mob + ", state=" + state + ", branch=" + branch + ", accno="
					+ accno + ", tdate=" + tdate + ", amount=" + amount + ", commission=" + commission + ", id=" + id
					+ "]";
		}

		public BankBean(String name, String mob, String state, String branch, String accno, String tdate, double amount,
				String commission, int id) {
			super();
			this.name = name;
			this.mob = mob;
			this.state = state;
			this.branch = branch;
			this.accno = accno;
			this.tdate = tdate;
			this.amount = amount;
			this.commission = commission;
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getMob() {
			return mob;
		}

		public void setMob(String mob) {
			this.mob = mob;
		}

		public String getState() {
			return state;
		}

		public void setState(String state) {
			this.state = state;
		}

		public String getBranch() {
			return branch;
		}

		public void setBranch(String branch) {
			this.branch = branch;
		}

		public String getAccno() {
			return accno;
		}

		public void setAccno(String accno) {
			this.accno = accno;
		}

		public String getDate() {
			return tdate;
		}

		public void setDate(String date) {
			this.tdate = date;
		}

		public double getAmount() {
			return amount;
		}

		public void setAmount(double amount) {
			this.amount = amount;
		}

		public String getCommission() {
			return commission;
		}

		public void setCommission(String commission) {
			this.commission = commission;
		}

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public BankBean(String name, String mob, String state, String branch, String accno, double amount,
				String commission) {
			super();
			this.name = name;
			this.mob = mob;
			this.state = state;
			this.branch = branch;
			this.accno = accno;
			this.amount = amount;
			this.commission = commission;
		}
	    
	    
	    
	}



