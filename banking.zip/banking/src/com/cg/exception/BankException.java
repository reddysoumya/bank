package com.cg.exception;

public class BankException {

}
