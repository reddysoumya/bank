package com.cg.dao;

import java.sql.SQLException;

import com.cg.bean.BankBean;

public interface IDao {

	int addinfo(BankBean bean) throws SQLException;

	BankBean retrievebyid(int id);

}
