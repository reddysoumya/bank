package com.cg.dao;

public interface IQuery {

	public static final String insert_qry ="insert into bank values(?,?,?,?,?,sysdate,?,?,seq.nextval)";
	public static final String id = "select seq.currval from dual";
	public static final String ret = "select * from bank where id=?";

}
