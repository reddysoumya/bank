package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.cg.bean.BankBean;
import com.cg.util.DBUtil;

public class DaoImpl implements IDao {
Connection conn=null;
static int sta=0;
static int recid=0;
	@Override
	public int addinfo(BankBean bean) throws SQLException {
		conn=DBUtil.getDbConnection();
		try
		{
		PreparedStatement pst=conn.prepareStatement(IQuery.insert_qry);
		pst.setString(1,bean.getName());
		pst.setString(2, bean.getMob());
		pst.setString(3, bean.getState());
		pst.setString(4, bean.getBranch());
		pst.setString(5,bean.getAccno());
		pst.setDouble(6, bean.getAmount());
		pst.setString(7, bean.getCommission());
		sta=pst.executeUpdate();
		} catch(SQLException e)
		{
			System.out.println(e.getMessage());
		}		
		try {
		
		PreparedStatement pst1=conn.prepareStatement(IQuery.id);
		//pst1.setInt(1, bean.getId());
		ResultSet rs=pst1.executeQuery();
		//System.out.println(rs.getInt(1));
		if(rs.next())
		{
			recid=rs.getInt(1);
		}
		} catch(SQLException e) {
			System.out.println(e.getMessage());
		}
		return recid;
	}
	@Override
	public BankBean retrievebyid(int id) {
		conn=DBUtil.getDbConnection();
		 BankBean b1=null;
		 try
		 {
		PreparedStatement pst2=conn.prepareStatement(IQuery.ret);
		pst2.setInt(1,id);
		ResultSet rs=pst2.executeQuery();
		while(rs.next())
		{
			b1=new BankBean(rs.getString(1),rs.getString(2), rs.getString(3), rs.getString(4),
					rs.getString(5), rs.getString(6), 
					rs.getDouble(7), rs.getString(8),rs.getInt(9));
		}
		 } catch(SQLException e)
		 {
			 System.out.println(e.getMessage());
		 }
		return b1;
	}

}
