package com.cg.util;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private static Connection conn=null;
	public static Connection getDbConnection()
	{
		String url="jdbc:oracle:thin:@localhost:1521:xe";
		String un="AVINASH";
		String pass="avinash";
		try {
			conn=DriverManager.getConnection(url,un,pass);
		} catch (SQLException e) {
			System.out.println("connection problem"+e.getMessage());
		}
		return conn;
	}
	
	
	

}




